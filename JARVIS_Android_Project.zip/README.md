# JARVIS Android
Open this project in Android Studio. Let Gradle sync. Then choose:
Build > Build APK(s)
The APK will be at app/build/outputs/apk/debug/app-debug.apk

The first version uses Android's SpeechRecognizer and TextToSpeech. It supports Arise/Sleep, YouTube, Google, Gmail, ChatGPT, web search and time. Continuous background wake-word listening can be added after this basic APK is tested.
