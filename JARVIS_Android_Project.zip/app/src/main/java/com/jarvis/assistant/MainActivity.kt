package com.jarvis.assistant

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Locale

class MainActivity: ComponentActivity(), TextToSpeech.OnInitListener {
 private var tts:TextToSpeech?=null; private var rec:SpeechRecognizer?=null; private var active=false
 private val perm=registerForActivityResult(ActivityResultContracts.RequestPermission()){if(it)speak("JARVIS is ready. Say Arise to activate.")}
 override fun onCreate(b:Bundle?){super.onCreate(b);tts=TextToSpeech(this,this);setContent{
  var status by remember{mutableStateOf("SLEEPING")};var heard by remember{mutableStateOf("Say Arise")};var response by remember{mutableStateOf("At your service.")}
  UI(status,heard,response){startListen({t->heard=t;val r=handle(t);status=r.first;response=r.second;speak(r.second)},{status=it})}
 };if(checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED)perm.launch(Manifest.permission.RECORD_AUDIO)}
 override fun onInit(r:Int){if(r==TextToSpeech.SUCCESS){tts?.language=Locale.US;tts?.setSpeechRate(.9f)}}
 private fun speak(s:String){tts?.speak(s,TextToSpeech.QUEUE_FLUSH,null,"jarvis")}
 private fun startListen(done:(String)->Unit,state:(String)->Unit){
  if(!SpeechRecognizer.isRecognitionAvailable(this)){speak("Speech recognition is not available on this phone.");return}
  rec?.destroy();rec=SpeechRecognizer.createSpeechRecognizer(this)
  rec?.setRecognitionListener(object:RecognitionListener{
   override fun onReadyForSpeech(p:Bundle?){state(if(active)"ACTIVE" else "LISTENING")}
   override fun onResults(r:Bundle?){val t=r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty();if(t.isNotBlank())done(t);state(if(active)"ACTIVE" else "SLEEPING")}
   override fun onError(e:Int){state(if(active)"ACTIVE" else "SLEEPING")}
   override fun onBeginningOfSpeech(){};override fun onRmsChanged(v:Float){};override fun onBufferReceived(b:ByteArray?){};override fun onEndOfSpeech(){};override fun onPartialResults(b:Bundle?){};override fun onEvent(e:Int,b:Bundle?){}
  })
  rec?.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply{putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);putExtra(RecognizerIntent.EXTRA_LANGUAGE,Locale.US);putExtra(RecognizerIntent.EXTRA_MAX_RESULTS,1)})
 }
 private fun handle(raw:String):Pair<String,String>{
  val low=raw.lowercase().trim()
  if(!active){if(low.contains("arise")||low=="rise"){active=true;return "ACTIVE" to "Yes?"};return "SLEEPING" to "Say Arise to activate me."}
  if(low=="sleep"||low.contains("go to sleep")||low.contains("stand by")){active=false;return "SLEEPING" to "Going to sleep."}
  val c=low.replace(Regex("^hey jarvis[,.\\s]*"),"").replace(Regex("^jarvis[,.\\s]*"),"").trim()
  fun web(u:String,m:String)="ACTIVE" to run(u,m)
  return when{
   c=="open youtube"->{web("https://www.youtube.com","Opening YouTube.")}
   c.startsWith("search youtube for ")->{val q=c.removePrefix("search youtube for ");web("https://www.youtube.com/results?search_query="+Uri.encode(q),"Searching YouTube for $q.")}
   c.startsWith("play ")->{val q=c.removePrefix("play ");web("https://www.youtube.com/results?search_query="+Uri.encode(q),"Searching YouTube for $q.")}
   c=="open google"->{web("https://www.google.com","Opening Google.")}
   c.startsWith("search ")||c.startsWith("google ")->{val q=c.substringAfter(" ");web("https://www.google.com/search?q="+Uri.encode(q),"Searching for $q.")}
   c=="open gmail"->{web("https://mail.google.com","Opening Gmail.")}
   c=="open chatgpt"->{web("https://chatgpt.com","Opening ChatGPT.")}
   c=="what time is it"||c=="time"->"ACTIVE" to "It is "+java.text.SimpleDateFormat("hh:mm a",Locale.US).format(java.util.Date())+"."
   else->"ACTIVE" to "I heard you, but I don't have an action for that yet."
  }
 }
 private fun run(url:String,msg:String):String{startActivity(Intent(Intent.ACTION_VIEW,Uri.parse(url)));return msg}
 override fun onDestroy(){rec?.destroy();tts?.shutdown();super.onDestroy()}
}

@Composable fun UI(status:String,heard:String,response:String,onMic:()->Unit){
 val bg=Color(0xFF05090D);val cyan=Color(0xFF00E5FF);val green=Color(0xFF00FF9D);val muted=Color(0xFF6F9AA4)
 Surface(Modifier.fillMaxSize(),color=bg){Column(Modifier.fillMaxSize().padding(22.dp),horizontalAlignment=Alignment.CenterHorizontally){
  Text("PERSONAL ASSISTANT // LOCAL MODE",color=muted,fontSize=11.sp,fontWeight=FontWeight.Bold)
  Text("JARVIS.",color=Color(0xFFD9FAFF),fontSize=38.sp,fontWeight=FontWeight.Bold)
  Spacer(Modifier.height(45.dp))
  Box(Modifier.size(230.dp).background(Color(0xFF071820),CircleShape).clickable{onMic()},contentAlignment=Alignment.Center){Text("J",color=cyan,fontSize=92.sp,fontWeight=FontWeight.Bold)}
  Spacer(Modifier.height(25.dp));Text(status,color=cyan,fontSize=17.sp,fontWeight=FontWeight.Bold)
  Text(if(status=="ACTIVE")"Listening for commands" else "Say "Arise" to activate",color=muted,fontSize=12.sp)
  Spacer(Modifier.height(35.dp))
  Card(colors=CardDefaults.cardColors(containerColor=Color(0xFF0B141B)),modifier=Modifier.fillMaxWidth()){Column(Modifier.padding(18.dp)){
   Text("LIVE TRANSCRIPT",color=muted,fontSize=10.sp);Text(heard,color=Color(0xFFD9FAFF),fontSize=15.sp,modifier=Modifier.padding(top=6.dp))
   Spacer(Modifier.height(20.dp));Text("JARVIS RESPONSE",color=muted,fontSize=10.sp);Text(response,color=green,fontSize=15.sp,modifier=Modifier.padding(top=6.dp))
  }}
  Spacer(Modifier.weight(1f));Button(onClick=onMic,modifier=Modifier.fillMaxWidth(),colors=ButtonDefaults.buttonColors(containerColor=Color(0xFF10232B),contentColor=cyan)){Text("🎙  SPEAK TO JARVIS")}
  Spacer(Modifier.height(8.dp));Text("VOICE: ARISE → COMMANDS → SLEEP",color=muted,fontSize=9.sp)
 }}
}